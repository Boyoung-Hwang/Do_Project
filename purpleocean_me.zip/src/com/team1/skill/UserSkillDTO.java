package com.team1.skill;

public class UserSkillDTO
{
	private int skId, usId;

	public int getSkId()
	{
		return skId;
	}

	public void setSkId(int skId)
	{
		this.skId = skId;
	}

	public int getUsId()
	{
		return usId;
	}

	public void setUsId(int usId)
	{
		this.usId = usId;
	}
	
	
}
