/*
	peopleDTO.java
*/

package com.team1.people;

public class peopleDTO
{
	private int peoId, peoCount;

	public int getPeoId()
	{
		return peoId;
	}

	public void setPeoId(int peoId)
	{
		this.peoId = peoId;
	}

	public int getPeoCount()
	{
		return peoCount;
	}

	public void setPeoCount(int peoCount)
	{
		this.peoCount = peoCount;
	}
}