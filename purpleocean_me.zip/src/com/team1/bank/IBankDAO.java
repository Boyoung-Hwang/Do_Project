package com.team1.bank;

import java.util.ArrayList;

public interface IBankDAO
{
	public ArrayList<String> lists();
}
