package com.team1.bank;

public class UserBankDTO
{
	private int bkiId, usId, bkId;
	private String account;
	
	public int getBkiId()
	{
		return bkiId;
	}
	public void setBkiId(int bkiId)
	{
		this.bkiId = bkiId;
	}
	public int getUsId()
	{
		return usId;
	}
	public void setUsId(int usId)
	{
		this.usId = usId;
	}
	public int getBkId()
	{
		return bkId;
	}
	public void setBkId(int bkId)
	{
		this.bkId = bkId;
	}
	public String getAccount()
	{
		return account;
	}
	public void setAccount(String account)
	{
		this.account = account;
	}
	
	
	
}
