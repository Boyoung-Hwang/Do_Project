/*
	MemberEstimateListDTO.java
*/

package com.team1.pro.member.estimateList;

public class MemberEstimateListDTO {

	private int melId;
	private String meContent;
	
	public int getMelId() {
		return melId;
	}
	public void setMelId(int melId) {
		this.melId = melId;
	}
	public String getMeContent() {
		return meContent;
	}
	public void setMeContent(String meContent) {
		this.meContent = meContent;
	}
	
	
}
